var classtime_out =
[
    [ "timeOut", "classtime_out.html#a2cffa89f7b90e4501e07e8cb7ccb3117", null ],
    [ "elapsedTime_ms", "classtime_out.html#af5db5b5f0db4f6ada19187ef8f214214", null ],
    [ "initTimer", "classtime_out.html#a88b4caef4ce7bfc42b73a61589c098e8", null ]
];