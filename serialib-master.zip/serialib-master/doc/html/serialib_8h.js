var serialib_8h =
[
    [ "serialib", "classserialib.html", "classserialib" ],
    [ "timeOut", "classtime_out.html", "classtime_out" ],
    [ "UNUSED", "serialib_8h.html#a86d500a34c624c2cae56bc25a31b12f3", null ],
    [ "SerialDataBits", "serialib_8h.html#a1ecb786dca6b3ea0df424552bd25aba7", [
      [ "SERIAL_DATABITS_5", "serialib_8h.html#a1ecb786dca6b3ea0df424552bd25aba7a0af46a1b1917daf04f071cc62409b1d0", null ],
      [ "SERIAL_DATABITS_6", "serialib_8h.html#a1ecb786dca6b3ea0df424552bd25aba7af037109ad2db2f77d36c2a9806b23978", null ],
      [ "SERIAL_DATABITS_7", "serialib_8h.html#a1ecb786dca6b3ea0df424552bd25aba7aeaccb09be92b75b1ac6a327eb21fb161", null ],
      [ "SERIAL_DATABITS_8", "serialib_8h.html#a1ecb786dca6b3ea0df424552bd25aba7ae7d27f5b5b60277dccbadd399897606d", null ],
      [ "SERIAL_DATABITS_16", "serialib_8h.html#a1ecb786dca6b3ea0df424552bd25aba7a5c284f8eb4f32fa561544a95e506227d", null ]
    ] ],
    [ "SerialParity", "serialib_8h.html#a2c48912c12fd98a4f4faffbc7f20a9f6", [
      [ "SERIAL_PARITY_NONE", "serialib_8h.html#a2c48912c12fd98a4f4faffbc7f20a9f6a38bc0d79b89ff9341767232da5448fe8", null ],
      [ "SERIAL_PARITY_EVEN", "serialib_8h.html#a2c48912c12fd98a4f4faffbc7f20a9f6a0392c989829d4e47a2cc54a12cb6125a", null ],
      [ "SERIAL_PARITY_ODD", "serialib_8h.html#a2c48912c12fd98a4f4faffbc7f20a9f6ab3213e8e4b9f1199aac388ed1b671a6e", null ],
      [ "SERIAL_PARITY_MARK", "serialib_8h.html#a2c48912c12fd98a4f4faffbc7f20a9f6a2ba4057e060ceb427fb3105ef629ccf6", null ],
      [ "SERIAL_PARITY_SPACE", "serialib_8h.html#a2c48912c12fd98a4f4faffbc7f20a9f6a10bed0b14962edaf7e883bf186d4773b", null ]
    ] ],
    [ "SerialStopBits", "serialib_8h.html#aa2678ddd8376c65d7cad07cd6cae5654", [
      [ "SERIAL_STOPBITS_1", "serialib_8h.html#aa2678ddd8376c65d7cad07cd6cae5654a5d487c59b00736410f8512b345ce6a0d", null ],
      [ "SERIAL_STOPBITS_1_5", "serialib_8h.html#aa2678ddd8376c65d7cad07cd6cae5654a5e9a6cef3d12988dba0fa9b9053ec3cc", null ],
      [ "SERIAL_STOPBITS_2", "serialib_8h.html#aa2678ddd8376c65d7cad07cd6cae5654a031c032346661741186af9d0680782ec", null ]
    ] ]
];