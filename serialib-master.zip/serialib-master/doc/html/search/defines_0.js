var searchData=
[
  ['unused_93',['UNUSED',['../serialib_8h.html#a86d500a34c624c2cae56bc25a31b12f3',1,'serialib.h']]]
];
