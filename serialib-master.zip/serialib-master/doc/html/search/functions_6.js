var searchData=
[
  ['opendevice_64',['openDevice',['../classserialib.html#afcef685b74a3db58dc2d1898bb34aaca',1,'serialib']]]
];
