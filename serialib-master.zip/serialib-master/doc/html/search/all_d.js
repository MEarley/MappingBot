var searchData=
[
  ['_7eserialib',['~serialib',['../classserialib.html#ac44215001ae198f2c196bb7993327a4b',1,'serialib']]]
];
