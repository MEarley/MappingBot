# Serialib

Serialib is a simple C++ library for serial communication. The library has been designed to work under Linux and Windows.

More details on [Lulu's blog](https://lucidar.me/en/serialib/cross-plateform-rs232-serial-library/)
